package Data.Iris;

/**
 * Enum for the different iris classes.
 */
public enum IrisClass {
    Iris_setosa,
    Iris_versicolor,
    Iris_virginica
}
