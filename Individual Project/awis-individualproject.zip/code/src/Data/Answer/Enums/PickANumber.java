package Data.Answer.Enums;

/**
 * Created by ander on 15-04-2017.
 */
public enum PickANumber {
    _7,
    _9,
    Asparagus,
    _13
}
