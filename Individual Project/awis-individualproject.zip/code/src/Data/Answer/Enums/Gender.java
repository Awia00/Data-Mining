package Data.Answer.Enums;

/**
 * Created by ander on 15-04-2017.
 */
public enum Gender {
    None,
    Male,
    Female
}
