package Data.Answer.Enums;

/**
 * Created by ander on 15-04-2017.
 */
public enum DegreeEnum {
    Games_A,
    Games_T,
    SDT_SE,
    SDT_DT,
    SWU,
    Guest,
    Other
}
