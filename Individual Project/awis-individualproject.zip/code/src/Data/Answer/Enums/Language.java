package Data.Answer.Enums;

/**
 * Created by ander on 15-04-2017.
 */
public enum Language {
    CSharp,
    Java,
    SQL,
    JavaScript,
    Python,
    Cpp,
    C,
    PHP,
    Swift,
    Ruby,
    R, HTML, CSS, FSharp, Scala, VisualBasic, Lua, Pascal, Haskell, Other
}
