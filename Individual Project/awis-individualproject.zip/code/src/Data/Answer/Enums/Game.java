package Data.Answer.Enums;

/**
 * Created by ander on 15-04-2017.
 */
public enum Game {
    CandyCrush,
    WordFeud,
    MineCraft,
    FarmVille,
    FiFa2017,
    StarWarsBattlefield,
    LifeIsStrange,
    Battlefield4,
    Journey,
    GoneHome,
    StanleyParable,
    CallOfDutyBlackOps,
    RocketLeague,
    BloodThorne,
    RiseOfTheTombRaider,
    TheWitness,
    HerStory,
    Fallout4,
    DragonAgeInquisition,
    CounterStrikeGO,
    AngryBirds,
    TheLastOfUs,
    TheMagicCircle,
    None,
}
