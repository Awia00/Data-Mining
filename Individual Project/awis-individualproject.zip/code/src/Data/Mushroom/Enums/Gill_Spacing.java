package Data.Mushroom.Enums;

public enum Gill_Spacing {
    close,
    crowded,
    distant
}
