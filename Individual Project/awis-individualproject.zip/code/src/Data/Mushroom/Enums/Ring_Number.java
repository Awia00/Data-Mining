package Data.Mushroom.Enums;

public enum Ring_Number {
    none,
    one,
    two
}
