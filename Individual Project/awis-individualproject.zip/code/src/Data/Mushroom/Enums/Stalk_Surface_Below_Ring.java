package Data.Mushroom.Enums;

public enum Stalk_Surface_Below_Ring {
    ibrous,
    scaly,
    silky,
    smooth
}
