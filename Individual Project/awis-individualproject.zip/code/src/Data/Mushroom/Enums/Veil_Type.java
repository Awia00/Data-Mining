package Data.Mushroom.Enums;

public enum Veil_Type {
    partial,
    universal
}
