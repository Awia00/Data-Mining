package Data.Mushroom.Enums;

public enum Stalk_Shape {
    enlarging,
    tapering
}
