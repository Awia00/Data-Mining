package Data.Mushroom.Enums;

public enum Bruises {
    bruises,
    no_bruises
}
