package Data.Mushroom.Enums;

public enum Cap_Shape {
    bell,
    conical,
    convex,
    flat,
    knobbed,
    sunken
}
