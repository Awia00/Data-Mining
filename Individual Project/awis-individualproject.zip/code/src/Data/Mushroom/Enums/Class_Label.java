package Data.Mushroom.Enums;

public enum Class_Label {
    edible,
    poisonous
}
