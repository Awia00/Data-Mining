package Data.Mushroom.Enums;

public enum Gill_Size {
    broad,
    narrow
}
