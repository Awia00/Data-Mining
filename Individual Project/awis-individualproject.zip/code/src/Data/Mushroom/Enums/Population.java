package Data.Mushroom.Enums;

public enum Population {
    abundant,
    clustered,
    numerous,
    scattered,
    several,
    solitary
}
