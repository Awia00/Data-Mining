package Data.Mushroom.Enums;

public enum Veil_Color {
    brown,
    orange,
    white,
    yellow
}
