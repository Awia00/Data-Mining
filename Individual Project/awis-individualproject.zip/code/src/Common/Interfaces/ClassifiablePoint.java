package Common.Interfaces;

import Common.DataTypes.Nominal;

/**
 * Created by ander on 20-03-2017.
 */
public interface ClassifiablePoint<T extends Nominal> extends Classifiable<T>, NDimensionalPoint {
}
