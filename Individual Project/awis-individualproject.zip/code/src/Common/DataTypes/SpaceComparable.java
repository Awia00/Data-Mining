package Common.DataTypes;

/**
 * Created by aws on 22-02-2017.
 */
public interface SpaceComparable<T>{

    double distance(T comparable);
}
